// Empty - no content script triggers
console.log('[DEBUG] Content script loaded (disabled)');
