// CSP bypass loader - injects forcer into MAIN world
(function() {
  'use strict';
  
  // Create script element in MAIN world
  const script = document.createElement('script');
  script.textContent = `(${wofForcer.toString()})();`;
  document.documentElement.appendChild(script);
  script.remove();
  
  // The actual forcer code (copied from your Tampermonkey script)
  function wofForcer() {
    const SHOW_PANEL = false;
    const _orig = crypto.getRandomValues.bind(crypto);
    const UINT32_MAX = 4294967295;
    const TRAVEL_FRACTION = 3 / 8;
    const ARM_WINDOW_MS = 2500;

    let targetName = null;
    let enabled = true;
    let armedUntil = 0;
    let hudTimeoutId = null;

    function getWheelConfig() {
      try {
        const pinia = document.querySelector('#q-app')
          ?.__vue_app__?.config?.globalProperties?.$pinia;
        return pinia?.state?.value?.wheel?.wheels?.[0]?.wheelConfig ?? null;
      } catch (_) {}
      return null;
    }

    function getEntries() {
      const wheelConfig = getWheelConfig();
      if (!Array.isArray(wheelConfig?.entries)) return null;
      const entries = wheelConfig.entries.filter(entry => entry?.enabled !== false);
      return entries.length ? entries : null;
    }

    function fractionForName(name) {
      const entries = getEntries();
      if (!entries?.length) return null;
      const idx = entries.findIndex(entry => entry.text === name);
      if (idx === -1) return null;
      const count = entries.length;
      return (((idx / count) - TRAVEL_FRACTION) % 1 + 1) % 1;
    }

    function armNextSpin() {
      if (!enabled || !targetName) return;
      render();
      if (!targetName) return;
      armedUntil = performance.now() + ARM_WINDOW_MS;
    }

    function isSpinTrigger(target) {
      if (!(target instanceof Element)) return false;
      if (panel && panel.contains(target)) return false;
      return !!target.closest('#q-app canvas, #q-app button, #q-app [role="button"]');
    }

    function isEditableTarget(target) {
      if (!(target instanceof Element)) return false;
      return target.matches('input, textarea, select, [contenteditable=""], [contenteditable="true"]');
    }

    function selectEntryByIndex(index) {
      const entries = getEntries() ?? [];
      const entry = entries[index];
      if (!entry) return false;
      targetName = entry.text;
      showHotkeyHud(index + 1);
      render();
      return true;
    }

    // CRITICAL: Hook crypto in MAIN world
    crypto.getRandomValues = function (typedArray) {
      _orig(typedArray);
      if (!enabled) return typedArray;
      if (!(typedArray instanceof Uint32Array)) return typedArray;
      if (typedArray.length !== 1) return typedArray;
      if (!targetName) return typedArray;
      if (performance.now() > armedUntil) return typedArray;

      const fraction = fractionForName(targetName);
      if (fraction === null) {
        console.log(`[WoF] "${targetName}" not found`);
        return typedArray;
      }

      const forced = Math.round(fraction * UINT32_MAX) >>> 0;
      console.log(`[WoF] target="${targetName}" fraction=${fraction.toFixed(6)} forced=${forced}`);
      typedArray[0] = forced;
      return typedArray;
    };

    // UI + event handlers (same as original)
    const panel = SHOW_PANEL ? document.createElement('div') : null;
    if (panel) {
      panel.style.cssText = `
        position:fixed;bottom:20px;right:20px;z-index:99999;
        background:#1e2021;border:2px solid #3369e8;border-radius:10px;
        padding:12px 16px;color:#e8e6e3;font-family:sans-serif;
        font-size:14px;box-shadow:0 0 12px #0008;min-width:240px;
        max-height:80vh;overflow-y:auto;
      `;
      (document.body || document.documentElement).appendChild(panel);
    }

    const hud = !SHOW_PANEL ? document.createElement('div') : null;
    if (hud) {
      hud.style.cssText = `
        position:fixed;bottom:12px;left:12px;z-index:99999;
        color:#8a8a8a;font-family:sans-serif;font-size:12px;
        pointer-events:none;opacity:0;transition:opacity 120ms ease;
      `;
      (document.body || document.documentElement).appendChild(hud);
    }

    function showHotkeyHud(slotNumber) {
      if (!hud) return;
      if (hudTimeoutId !== null) clearTimeout(hudTimeoutId);
      hud.textContent = String(slotNumber);
      hud.style.opacity = '1';
      hudTimeoutId = setTimeout(() => {
        hud.style.opacity = '0';
        hudTimeoutId = null;
      }, 1000);
    }

    function render() {
      if (!panel) return;
      const entries = getEntries() ?? [];
      const names = entries.map(entry => entry.text);
      if (targetName && !names.includes(targetName)) targetName = null;
      const fraction = targetName ? fractionForName(targetName) : null;

      panel.innerHTML = `
        <div style="font-weight:bold;margin-bottom:10px;color:#4292ea;">WoF Forcer</div>
        <label style="font-size:12px;display:block;margin-bottom:8px;">
          <input id="fw-enabled" type="checkbox" ${enabled ? 'checked' : ''}> Enabled
        </label>
        <div style="font-size:12px;margin-bottom:6px;color:#aaa;">Pick target (${names.length} entries):</div>
        <div id="fw-names" style="display:flex;flex-direction:column;gap:4px;"></div>
        <div style="margin-top:10px;font-size:11px;color:#555;">fraction: ${fraction !== null ? fraction.toFixed(6) : '---'}</div>
        <div style="margin-top:4px;font-size:11px;color:#555;">hotkeys: Shift+1..9, Shift+0 off</div>
        <button id="fw-refresh" style="margin-top:8px;width:100%;background:#2a2d2e;color:#aaa;border:1px solid #444;border-radius:4px;padding:4px;cursor:pointer;font-size:11px;">Refresh</button>
      `;

      const container = panel.querySelector('#fw-names');
      if (names.length === 0) {
        container.innerHTML = '<div style="color:#666;font-size:12px;">No entries yet.</div>';
      } else {
        names.forEach((name, i) => {
          const btn = document.createElement('button');
          btn.textContent = name;
          btn.style.cssText = `
            background:${name === targetName ? '#3369e8' : '#2a2d2e'};
            color:#e8e6e3;border:1px solid ${name === targetName ? '#3369e8' : '#444'};
            border-radius:4px;padding:4px 8px;cursor:pointer;font-size:13px;text-align:left;
          `;
          btn.onclick = () => { targetName = name; render(); };
          container.appendChild(btn);
        });
      }

      panel.querySelector('#fw-enabled').onchange = e => enabled = e.target.checked;
      panel.querySelector('#fw-refresh').onclick = render;
    }

    document.addEventListener('pointerdown', e => {
      if (isSpinTrigger(e.target)) armNextSpin();
    }, true);

    document.addEventListener('keydown', e => {
      if (!isEditableTarget(e.target) && e.shiftKey && e.code.startsWith('Digit')) {
        const digit = e.code.replace('Digit', '');
        if (digit === '0') {
          e.preventDefault();
          enabled = false;
          targetName = null;
          if (hud) showHotkeyHud(0);
          render();
          return;
        }
        const index = Number(digit) - 1;
        if (selectEntryByIndex(index)) {
          e.preventDefault();
          return;
        }
      }
      if ((e.key === 'Enter' || e.key === ' ') && isSpinTrigger(e.target)) {
        armNextSpin();
      }
    }, true);

    // Wait for page load then render
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => setTimeout(render, 500));
    } else {
      setTimeout(render, 500);
    }
    render();
  }
})();
